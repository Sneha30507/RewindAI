# Rewind AI Dashboard

Dark-themed, responsive dashboard UI built with plain HTML and CSS (no build step).

## Run locally
Open `index.html` in a browser.

## Structure
- `index.html` - page markup
- `css/style.css` - all styles

## Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit: Rewind AI dashboard"
git branch -M main
git remote add origin https://github.com/<your-username>/rewind-ai-dashboard.git
git push -u origin main
```
